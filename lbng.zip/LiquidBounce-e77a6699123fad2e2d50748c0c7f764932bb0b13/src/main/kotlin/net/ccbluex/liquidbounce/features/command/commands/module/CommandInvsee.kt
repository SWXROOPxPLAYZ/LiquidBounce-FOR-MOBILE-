/*
 * This file is part of LiquidBounce (https://github.com/CCBlueX/LiquidBounce)
 *
 * Copyright (c) 2015 - 2026 CCBlueX
 *
 * LiquidBounce is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * LiquidBounce is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with LiquidBounce. If not, see <https://www.gnu.org/licenses/>.
 */
package net.ccbluex.liquidbounce.features.command.commands.module

import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.features.command.CommandException
import net.ccbluex.liquidbounce.features.command.builder.CommandBuilder
import net.ccbluex.liquidbounce.features.command.builder.ParameterBuilder
import net.ccbluex.liquidbounce.features.command.builder.playerName
import net.ccbluex.liquidbounce.features.module.modules.misc.ModuleInventoryTracker
import net.ccbluex.liquidbounce.utils.client.mc
import net.ccbluex.liquidbounce.utils.client.network
import net.ccbluex.liquidbounce.utils.client.world
import net.ccbluex.liquidbounce.utils.inventory.ViewedInventoryScreen
import java.util.UUID

/**
 * Command Invsee
 *
 * ???
 *
 * Module: [ModuleInventoryTracker]
 */
object CommandInvsee : Command.Factory {

    var viewedPlayer: UUID? = null

    override fun createCommand(): Command {
        return CommandBuilder
            .begin("invsee")
            .requiresIngame()
            .parameter(
                ParameterBuilder.playerName()
                    .required()
                    .build()
            )
            .handler {
                val inputName = args[0] as String
                val playerID = network.onlinePlayers.find { it.profile.name.equals(inputName, true) }?.profile?.id
                val player = { playerID?.let(world::getPlayerByUUID) ?: ModuleInventoryTracker.playerMap[playerID] }

                if (playerID == null || player() == null) {
                    throw CommandException(command.result("playerNotFound", inputName))
                }

                mc.schedule {
                    mc.setScreen(ViewedInventoryScreen(player))
                }

                viewedPlayer = playerID
            }
            .build()
    }
}
